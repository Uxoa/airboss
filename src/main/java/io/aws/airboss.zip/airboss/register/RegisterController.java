package io.aws.airboss.register;

public class RegisterController {
}
