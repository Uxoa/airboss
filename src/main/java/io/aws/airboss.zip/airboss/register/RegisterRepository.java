package io.aws.airboss.register;

public class RegisterRepository{

}