package io.aws.airboss.bookings;

public enum BookingStatus {
    CREATED,
    PENDING,
    CONFIRMED,
    CANCELLED
}
